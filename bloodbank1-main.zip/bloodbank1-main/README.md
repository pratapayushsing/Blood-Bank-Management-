The project aims to implement an efficient cloud-based blood banking system. 
This project uses AWS as the Cloud Service provider and uses amplify service to develop as well as deploy the complete application.
